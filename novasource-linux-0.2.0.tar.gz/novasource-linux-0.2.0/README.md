# NovaSource

**NovaSource** is a small, original C++ game engine for **Linux only** — no
Windows. It is built on SDL2 + OpenGL and ships with a playable demo game,
**Nova Fortress**, a TF2-inspired arena shooter made from scratch (original
shapes, colours and code only — no Valve assets).

Version: **0.2.0**

## What the engine provides

- `ns::Engine` — window + OpenGL context, 60 FPS game loop, delta time
- Keyboard + mouse input (held / pressed-this-frame, relative mouse look)
- First-person `ns::Camera` with yaw/pitch
- 3D drawing helpers: grid floor, boxes, spheres, lines
- 2D HUD text (TrueType, cached textures)
- Math helpers: `Vec3`, ray-vs-sphere, clamp, random
- `ns::Game` framework: implement `Update()` / `Render()`, hand it to
  `ns::RunGame()` — see `src/demo_main.cpp` for a complete example

## How to build

Requirements (Ubuntu/Debian):

```sh
sudo apt install build-essential cmake libsdl2-dev libsdl2-ttf-dev libgl1-mesa-dev
```

Build:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
```

Run the demo game:

```sh
./build/novasource            # play it (WASD + mouse, click to shoot, SPACE to jump)
./build/novasource --auto     # autopilot mode (plays itself, for recordings)
```

## TF2 systems inside NovaSource

NovaSource now runs real TF2 gameplay logic, ported from the formulas in
Valve's TF2 source code (`~/workspace/apps/tf2-sdk/source-sdk-2013/`).
No Source engine code was copied — the SDK code can't compile standalone —
each system was re-implemented in `include/novasource/tf2.h` /
`src/tf2.cpp`. Scale: 1 NovaSource unit = 60 Hammer units.

1. **Player classes** — Scout (125 HP, 400 HU/s, fast and fragile),
   Soldier (200 HP, 240 HU/s, balanced), Heavy (300 HP, 230 HU/s, slow
   and tough). Switch with `1` / `2` / `3`. Blueprint:
   `src/game/shared/tf/tf_classdata.cpp` (`health_max` / `speed_max`).
2. **TF2 movement** — velocity-based movement with ground friction,
   acceleration and air control, plus jumping, using TF2's constants
   (`sv_accelerate` 10, `sv_friction` 4, `sv_airaccelerate` 10,
   `sv_stopspeed` 100, air speed cap 30 HU/s, gravity 800 HU/s², jump
   impulse √(2·gravity·21 HU)). Blueprint:
   `src/game/shared/movevars_shared.cpp`,
   `src/game/shared/gamemovement.cpp` (`Friction`, `Accelerate`,
   `AirAccelerate`, `CheckJumpButton`),
   `src/game/shared/tf/tf_gamemovement.cpp`.
3. **TF2 weapons** — Scattergun: 10 pellets, 6 base damage each, with
   TF2's distance falloff (full damage up close, fading to zero at twice
   the 512 HU optimal distance, ±10% random spread). Rocket Launcher:
   90 base damage, 1100 HU/s projectile, radius damage with TF2's
   explosive falloff. Switch with `E`. Blueprint:
   `src/game/shared/tf/tf_weaponbase_gun.cpp` (`FireBullet`,
   `GetProjectileDamage`), `src/game/shared/tf/tf_weapon_shotgun.cpp`
   (`CTFScatterGun`), `src/game/shared/tf/tf_weaponbase_rocket.cpp`
   (launch speed 1100 HU/s), `src/game/shared/tf/tf_gamerules.cpp`
   (bullet falloff, `CTFRadiusDamageInfo`).

Drones now have 60 HP (with a health bar) instead of dying to one shot,
so the weapons and falloff actually matter.

**License note:** the TF2-derived logic above is under Valve's Source 1
SDK License (non-commercial) — anything built from TF2 code must be free.
The rest of NovaSource is MIT. No Valve models, textures, sounds or maps
are used anywhere.

## Share your source code

At boot, sometimes (~1 in 3 launches) Nova Fortress asks on the menu
screen: "Want to share your own source code?" — with **Yes / Not now /
Don't ask again**. It never appears during gameplay or after a match, and
never in autopilot (`--auto`) recordings. "Don't ask again" is saved in
`~/.config/novasource/config` and respected permanently.

Picking **Yes** opens a folder picker (or lets you type a path) and
packages the folder you choose into a `.tar.gz` in
`~/nova-fortress-shared/` that you can share yourself. Nothing is
uploaded anywhere — there is no server yet. A real upload spot inside
Ember Launcher is coming later.

## How to play Nova Fortress

- **Goal:** score 25 points before the 90-second clock runs out.
- Grab gold orbs (**+1**) and blast RED drones (**+2**, they have 60 HP).
- Drones chase you and cost 10 HP on contact. You lose at 0 HP or at 0:00.
- `1` / `2` / `3` switch class (Scout / Soldier / Heavy), `E` swaps
  weapon (Scattergun / Rocket Launcher), `WASD` move, mouse to look,
  `SPACE` to jump, click to shoot, `R` to restart after a win/loss,
  `Esc` to quit, `F1` toggles autopilot.

## How to make your own game with NovaSource

1. Write a class that inherits from `ns::Game` and implements `Update()`
   and `Render()` (copy `src/demo_main.cpp` as a starting point).
2. Add it as a new executable in `CMakeLists.txt` linking `novasource`.
3. Build and run — the engine handles the window, loop, input and drawing.

## Releases

Versioned Linux builds live in `releases/` as
`novasource-linux-<version>.tar.gz` (binary + README + VERSION + LICENSE).
The launcher can offer this archive for download and install.

## Notes

- Linux only by design. The engine needs an X display (Xvfb works fine).
- TF2-derived gameplay logic (classes, movement, weapons) is
  non-commercial under the Source 1 SDK License — see "TF2 systems
  inside NovaSource" above. The TF2 source itself lives separately in
  `~/workspace/apps/tf2-sdk/`.
